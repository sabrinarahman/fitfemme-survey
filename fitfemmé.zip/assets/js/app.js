function init() {
	debugger;
	replaceQuestion(myQuestions[0]);
}
function appendAnswers(answers) {
	var answerHTML = "";
	answers.forEach( function(letter) {
		answerHTML += 
		`<button class="button">
			<i class="fa fa-female"></i> ` + answer.letter + `
		</button>`
	})
	return answerHTML;
}

function replaceQuestion(question) {
	var answers = appendAnswers(question.answers);
	$('header').html(
		`<h1>` + question.question + `</h1>` +
		answers
	)
}

init();