const myQuestions = [
  {
    question: "What kind of trainer do you want to be?",
    answers: {
      a: "Class Instructor",
      b: "One on One Trainer",
    }
  },
  {
    question: "What type of classes are you interested in teaching?",
    answers: {
      a: "Zumba",
      b: "HIIT",
      c: "Yoga"
    }
  },
  {
    question: "What kind of training are you interested in?",
    answers: {
      a: "Strength Training",
      b: "Functional Training",
      c: "Body Building"
    }
  },
];